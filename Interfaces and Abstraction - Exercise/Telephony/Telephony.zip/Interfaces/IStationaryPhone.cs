﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telephony.Interfaces
{
    public interface IStationaryPhone
    {
        public string Call(string phoneNumber);
    }
}
