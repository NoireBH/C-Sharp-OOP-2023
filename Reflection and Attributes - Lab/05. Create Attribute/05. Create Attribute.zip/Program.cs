﻿using System;

namespace AuthorProblem
{
    [Author("Elmir")]
    public class StartUp
    {
        [Author("Gosho")]
        static void Main(string[] args)
        {
           
        }
    }
}
