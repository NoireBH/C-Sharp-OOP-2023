﻿using FakeAxeAndDummy.Models.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace FakeAxeAndDummy.Models
{
    public class Axe : IWeapon
    {
        public int Damage {get; private set;}

    }
}
