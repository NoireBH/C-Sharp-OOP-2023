﻿namespace Problem04.BalancedParentheses
{
    public interface ISolvable
    {
        bool AreBalanced(string parentheses);
    }
}